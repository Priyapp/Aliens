package com.multunus.aliens.services;

public interface ExportService {

	/**
	 * Must return the format name to be used for display purpose and to be added to the file name
	 * @return format type (Eg : csv,txt etc)
	 */
	public String getFormatName();
	
	/**
	 * Export the alien data to your own format, use the provided file name for saving the data
	 * @param alienCodeName
	 * @param noOfLegs
	 * @param homePlanet
	 * @param fileName - complete path is given
	 * @return true if export is successful , else false
	 * @throws Exception
	 */
	public boolean exportData(String alienCodeName, int noOfLegs,String homePlanet, String fileName) throws Exception;
	
}
