
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import com.multunus.aliens.services.ExportServices;

public class TextExportService implements ExportServices{
 
	private final String formatName="TXT";
	@Override
	public String getFormatName() {
		// TODO Auto-generated method stub
		return formatName;
	}

	@Override
	public boolean exportData(String alienName, String bloodColor,
			int noOfAntennas, int noOfLegs, String homePlanet, String fileName)
			throws Exception {
		
		 FileWriter fw = null;
	      BufferedWriter bout = null;
	      try
	      {
	        fw = new FileWriter(fileName, true);
	        bout = new BufferedWriter(fw);
	        
	        bout.write("Code Name  " + alienName + System.getProperty("line.separator"));
	        bout.write("Blood Color  " + bloodColor + System.getProperty("line.separator"));	        
	        bout.write("No of Antennas "+noOfAntennas +System.getProperty("line.separator"));
	        bout.write("No of legs  " + noOfLegs + System.getProperty("line.separator"));
	        bout.write("Home Planet  " + homePlanet + System.getProperty("line.separator"));
	        bout.flush();
	      }
	      catch (IOException e)
	      {
	    	  System.out.println("Error :"+e.getMessage());
	      
	    	  return false;
	    	  
	      } finally {
	    	  
	    	  if(bout!=null) {
	    		  bout.close();
	    	  }
	    	  
	    	  if(fw!=null) {
	    		  fw.close();
	    	  }
	    	  
	      }
		
		return true;
		
		
	}

}
