package com.multunus.aliens;


import java.io.IOException;

import com.multunus.aliens.services.AlienFormatServices;
import com.multunus.aliens.services.AlienInputServices;
import com.multunus.aliens.services.FileServices;
import com.multunus.aliens.services.FormatServices;
import com.multunus.aliens.services.InputServices;

import com.multunus.aliens.services.SystemFileServices;
import com.multunus.aliens.util.AlienExceptions;

public class AlienPath {
public static void main(String[] args) {
	
	try{
		//location where application related files.
		//now sets to uers's home. It can be any.
       
		String appDirectory  =System.getProperty("user.home");	
       
        // Set application root directory name
    	String applicationRootFolderName = "Aliens";
       
    	//set plugin directory name, This is where we need to keep the plugin files 
		String formatPluginFolderName = "Plugins";

		// This is where the exported files will be saved
		String exportFolderName = "Export";
       
		FileServices fileServices	=new SystemFileServices(appDirectory,applicationRootFolderName,
				formatPluginFolderName, exportFolderName);
		
	    FormatServices formatServices = new AlienFormatServices(fileServices);
		
		InputServices inputServices = new AlienInputServices(formatServices);

		inputServices.printWelcomeMessage();

		inputServices.printMainMenu();
		
	}
	catch(AlienExceptions e){
		e.printStackTrace();
		
	} catch (Exception e) {
		
		System.out.println("Unhandled Exception : "+e.getMessage());
		
		System.out.println("Exiting application - Sorry for the troubles !!! ");
		
		System.exit(1);
		
	}
	
}
}
