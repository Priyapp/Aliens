package com.multunus.aliens.util;

public class AlienUtils {

	/**
	 * Check whether given number can be parsed to integer
	 * @param value
	 * @return true if value can be parsed to integer, false otherwise
	 */
	
	public static boolean isInteger(String value) {
		if (value == null) {
			return false;
		}
		int length = value.length();
		if (length == 0) {
			return false;
		}
		int i = 0;
		if (value.charAt(0) == '-') {
			if (length == 1) {
				return false;
			}
			i = 1;
		}
		for (; i < length; i++) {
			char c = value.charAt(i);
			if (c <= '/' || c >= ':') {
				return false;
			}
		}
		return true;
	}
	
}
