package com.multunus.aliens.util;

public class AlienExceptions extends Exception {

	/**
	 * default id
	 */
	private static final long serialVersionUID = 1L;

	public static final int CRITICAL = 1;
	
	public static final int WARNING = 2;
	
	private String message;
	
	private Exception sourceException ;
	
	private int level;

	public AlienExceptions(String message,Exception sourceException,int level) {
		super();
		this.message = message;
		this.sourceException=sourceException;
		this.level = level;
	}

	@Override
	public String getLocalizedMessage() {
		
		return getMessage();
	}

	@Override
	public String getMessage() {
		return message;
		
	}

	@Override
	public void printStackTrace() {
		
		if(sourceException!=null) {
			
			sourceException.printStackTrace();
			
		} else {
			
			System.out.println("Custom application message :"+message);
			
		}
		
	}
	
	
	
}
