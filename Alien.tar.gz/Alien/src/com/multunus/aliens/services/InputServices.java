package com.multunus.aliens.services;

public interface InputServices {

	/*
	 * Print application menu item
	 */
	public void printMainMenu() ;
	
	/*
	 * Print welcome messages
	 */
	
	public void printWelcomeMessage();	
	
	
}
