package com.multunus.aliens.services;

import java.io.BufferedReader;

import java.io.IOException;
import java.io.InputStreamReader;
import com.multunus.aliens.beans.Aliens;
import com.multunus.aliens.util.AlienExceptions;
import com.multunus.aliens.util.AlienUtils;

public class AlienInputServices implements InputServices{
	
	private FormatServices formatServices;
	
	private BufferedReader reader;
	
	public AlienInputServices(FormatServices formatServices ){
		
		this.formatServices =formatServices;
		
		reader=new BufferedReader(new InputStreamReader(System.in));
	}
	
	@Override
	public void printMainMenu() {
		// TODO Auto-generated method stub
		System.out.println("=================");
		
		System.out.println("1. New Registeration");
		
		System.out.println("2. Supported Export Formats");
		
		System.out.println("3. Help");
		
		System.out.println("4. Exit");
		
		System.out.println("Enter your choice:");
		
		handleMainMenuInput();
	}

	@Override
	public void printWelcomeMessage() {
		
		System.out.println("**** Hey Alien, Welcome TO Earth *** ");
		
	}
	
	private void handleMainMenuInput() {
		
		int userChoice =readUsersChoice();
		
		switch (userChoice) {
		case -1:
			System.out.println("Failed to capture your input. Cannot proceed further, Sorry !!!");
			
			if(reader!=null){
				try{
					reader.close();
					
				}catch(IOException e){
					
				}
				
			}
			System.exit(1);
			break;

			
		case 1:
			System.out.println("Hi Alien, Enter your details for registration");
			
			Aliens aliens=readAlienData();
			
			if(aliens!=null){
			
			try {
			
				
					System.out.println("Hi "+aliens.getName());
					
					formatServices.printAvailableExportMenu();
					
					formatServices.handleExportOption(aliens);
				
				
			}catch (AlienExceptions e) {
		 		
				System.out.println(e.getMessage());
				
				printMainMenu();
			}
			
		}else {
			
			System.out.println("We encountered some issues while capturing your details, Please try again later");
			
		}
		
		printMainMenu();
			
			break;
			
		case 2:
			try{
				
				formatServices.printAvailableExportMenu();
				
			}catch(AlienExceptions e){
				System.out.println(e.getMessage());
			}
			
			printMainMenu();
			break;
			
		case 3:
			System.out.println("		-	For registering a new export plugin, Copy your plugin.class file to "+ formatServices.getPluginDirectory()+ " and restart the app");

			System.out.println("		-	Your class should implement the ExportService interface, get the interface file from "+formatServices.getPluginDirectory());
			
			System.out.println("		-	Your plugin should have a default constructor, and should be in default package/no package");

			System.out.println("		-	If not, the plugin will not be registered with the system and system can crash");
			
			System.out.println("		-	Your class must return the format name using getFormatName method and export data to file using exportData method");

			printMainMenu();
			
			break;
			
		
		case 4:
			printExitMessage();
	      if(reader!=null) {
				
				try {
					reader.close();
				} catch (IOException e) {
					// TODO handle exceptions properly
					
				}
				
			}	
			
			break;
		case 0 : default:
			System.out.println("Invalid option, Please select a valid option");

			printMainMenu();
			break;
			
		
		}
		
		
	}
	

	public void printExitMessage() {

		System.out.println("Thank you for using Alien System, Have a nice day");

		System.out.println("**********END********");

		System.exit(0);

	}

	private Aliens readAlienData() {
		
		Aliens aliens= new Aliens();
		
		String name = null;
		try{
		System.out.println("What is your name");
		
		 name=reader.readLine();
		
		while(name.trim().length()==0 || name== null){
			
			System.out.println("Your name cannot empty. Please re enter your name");
			
			name=reader.readLine().trim();
		}
		aliens.setName(name);
		
         
		System.out.println("What is your Blood Color ?:");
		
		String bloodColor=reader.readLine();
		
		while(bloodColor.trim().length()==0 || bloodColor == null){
			
			System.out.println("Your blood color cannot empty. Please re enter your blood color");
			bloodColor=reader.readLine().trim();
		}
		aliens.setBloodColor(bloodColor);
	
		
        System.out.println("How many Antennas do you have ?:");
		
		String noOfAntennas=reader.readLine();
		
		while(!AlienUtils.isInteger(noOfAntennas) || Integer.parseInt(noOfAntennas)<0){
			
			System.out.println("Not a valid Number. Please re enter your Antennas");
			noOfAntennas=reader.readLine().trim();
		}
		aliens.setNoOfAnteannas(Integer.parseInt(noOfAntennas));
		
	
		System.out.println("How many legs do you have ?:");
		
		String noOfLegs=reader.readLine();
		while(!AlienUtils.isInteger(noOfLegs) || Integer.parseInt(noOfLegs)<0){
			
			System.out.println("Not a valid Number. Please re enter your legs");
			noOfLegs=reader.readLine().trim();
		}
		aliens.setNoOfLegs(Integer.parseInt(noOfLegs));
		
		

		System.out.println("Where are you from ?:");
		
		String homePlanet = reader.readLine().trim();

		while(homePlanet.trim().length()==0 || homePlanet == null) {
			
			System.out.println("Your home planet field cannot be left blank, Please re enter");
			
			homePlanet = reader.readLine().trim();
			
		}		
		
		aliens.setHomePlanet(homePlanet);
		
	
		
		
	}catch (IOException ioe) {

		
		return null;

	}
		
		return aliens;
	}
	
	private int readUsersChoice() {
		
		 String input =null;
		 int choice;
		 
		try {
			
			input=reader.readLine();
			
			choice=Integer.parseInt(input);
			
			
		} catch (IOException e) {
			
			e.printStackTrace();
			choice =-1;
			
		}catch(NumberFormatException e){
			
			 choice = 0;
			 
		}catch(Exception e){
			
			choice = 0;
		}
		 
		
		
		return choice;
	}


	

	
}
