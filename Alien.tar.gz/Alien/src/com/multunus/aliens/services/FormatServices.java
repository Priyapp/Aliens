package com.multunus.aliens.services;

import com.multunus.aliens.beans.Aliens;

import com.multunus.aliens.util.AlienExceptions;

public interface FormatServices {

	public String getPluginDirectory();
	
	/**
	 * This method should print the available export options (plugins) in the form of a menu.
	 * eg : 1. csv
	 * 		2. txt
	 * @throws AlienExceptions 
	 * 
	 */
	public void printAvailableExportMenu() throws AlienExceptions;
	
	/**
	 * Take the export choice from user and act accordingly
	 * @throws AlienExceptions 
	 */
	public void handleExportOption(Aliens aliens) throws AlienExceptions;
	
}
