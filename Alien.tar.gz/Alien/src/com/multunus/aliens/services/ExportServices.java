package com.multunus.aliens.services;

public interface ExportServices {

	public String getFormatName();
	/**
	 * Must return the format name to be used for display purpose and to be added to the file name
	 * @return format type (Eg : csv,txt etc)
	**/
	public boolean exportData(String alienName, String bloodColor,int noOfAntennas,int noOfLegs,String homePlanet, String fileName) throws Exception;
	 
	/**
	 * Export the alien data to your own format, use the provided file name for saving the data
	 * @param alienCodeName
	 * @param noOfLegs
	 * @param homePlanet
	 * @param fileName - complete path is given
	 * @return true if export is successful , else false
	 * @throws Exception
	 */
	
}
