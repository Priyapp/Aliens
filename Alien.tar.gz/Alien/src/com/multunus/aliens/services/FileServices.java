package com.multunus.aliens.services;

public interface FileServices {

   public String getPluginFolder();
	
	public String getExportFolder();	
	
	public String getExportFileName(String fileName);
	
	public String getFormatPluginFileName(String fileName);
}
