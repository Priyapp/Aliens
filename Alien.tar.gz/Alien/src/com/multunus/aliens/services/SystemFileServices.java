package com.multunus.aliens.services;

import java.io.File;

import java.io.IOException;

import org.apache.commons.io.FileUtils;

import com.multunus.aliens.util.AlienExceptions;

public class SystemFileServices implements FileServices{
	
    private String appRootFolderName;
	
	private String appDirectory;
	
	private String pathSeperator;
	
	private String formatPluginFolder;
	
	private String exportFolder;

	private String formatPluginFolderName;
	
	private String exportFolderName;
	
	private final String csvExportPluginFile = "CsvExportService.class";

	private final String  txtExportPluginFile = "TextExportService.class";
	
	private final String  ExportInterFaceFilename = "ExportService.java";
	
	private final String backupFolderName = "SystemFormats";
	
	
	public SystemFileServices(String appRootDirectory,String appRootFolderName, String formatPluginFolderName, String exportFolderName) throws AlienExceptions {
		
		this.pathSeperator = System.getProperty("file.separator");
		
		this.appRootFolderName=appRootFolderName;
		
		this.appDirectory=appRootDirectory+this.pathSeperator+this.appRootFolderName;
		
		this.formatPluginFolderName=formatPluginFolderName;
		
		this.exportFolderName=this.appDirectory+this.pathSeperator+exportFolderName;
		
		exportFolder =this.appDirectory+this.pathSeperator+exportFolderName; 
		
		formatPluginFolder=this.appDirectory+this.pathSeperator+formatPluginFolderName;
		
		System.out.println("Application root directory is "+appDirectory);
	
		createAppFolder();
}

	private void createAppFolder() throws AlienExceptions {
		// TODO Auto-generated method stub
		File exportDirectory= new File(exportFolder);
		
		File pluginDirectory= new File(formatPluginFolder);

		File CsvExportPlugin = new File(getFormatPluginFileName(csvExportPluginFile));
		
        File txtExportPlugin = new File(getFormatPluginFileName(txtExportPluginFile));
        
		File ExportInterface = new File(getFormatPluginFileName(ExportInterFaceFilename));
		
		
		
		
		if(!exportDirectory.exists()){
			
			
			boolean isDirCreated = exportDirectory.mkdirs();
			
			
			if(!isDirCreated){
				throw new AlienExceptions("Failed to create export direcotry", null,AlienExceptions.CRITICAL);
			}
		}
		
		
		if(!pluginDirectory.exists()){
			
			
			boolean isDirCreated=pluginDirectory.mkdirs();
			
			if(!isDirCreated){
				throw new AlienExceptions("failed to create plugin Directory", null, AlienExceptions.CRITICAL);
			}
			
		}
		
             if(!CsvExportPlugin.exists()) {
			
			try {
				
				FileUtils.copyFile(new File(backupFolderName+"/"+csvExportPluginFile), CsvExportPlugin);
				
			} catch (IOException e) {
				
				System.out.println("########### WARNING ################");
				
				System.out.println(e.getMessage());
				
				System.out.println("Failed to initialize csv export plugin, Functionality will not be available");
				
				System.out.println("####################################");
				
				
			}
			
		}
		
		if(!txtExportPlugin.exists()) {
			
			try {
				
				FileUtils.copyFile(new File(backupFolderName+"/"+txtExportPluginFile), txtExportPlugin);
				
			} catch (IOException e) {
				
				System.out.println("########### WARNING ################");
				
				System.out.println(e.getMessage());
				
				System.out.println("Failed to initialize txt export plugin, Functionality will not be available");
				
				System.out.println("####################################");
			}
			
		}
		
		if(!ExportInterface.exists()) {
			
			try {
				
				FileUtils.copyFile(new File(backupFolderName+"/"+ExportInterFaceFilename), ExportInterface);
				
			} catch (IOException e) {
				
				System.out.println("########### WARNING ################");
				
				System.out.println(e.getMessage());
				
				System.out.println("Failed to copy the export interface file to plugin directory, use application help menu to get details");
				
				System.out.println("####################################");
			}
			
		}
		
		
	}

	@Override
	public String getPluginFolder() {
		// TODO Auto-generated method stub
		return formatPluginFolder;
	}

	@Override
	public String getExportFolder() {
		// TODO Auto-generated method stub
		return exportFolder;
	}

	@Override
	public String getExportFileName(String fileName) {
		// TODO Auto-generated method stub
		return exportFolder+pathSeperator+fileName;
	}

	@Override
	public String getFormatPluginFileName(String fileName) {
		// TODO Auto-generated method stub
		return formatPluginFolder+pathSeperator+fileName;
	}
}