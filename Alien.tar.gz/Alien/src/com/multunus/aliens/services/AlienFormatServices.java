package com.multunus.aliens.services;

import java.io.BufferedReader;

import java.io.File;
import java.io.FileReader;
import java.io.InputStreamReader;

import java.lang.reflect.InvocationTargetException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.multunus.aliens.services.*;
import com.multunus.aliens.beans.Aliens;
import com.multunus.aliens.util.AlienExceptions;
import com.multunus.aliens.util.AlienUtils;

public class AlienFormatServices implements FormatServices{
	
	private FileServices fileServices;
	
	private Integer pluginCounter=1;
	
	private HashMap<Integer, String> exportMenu=new HashMap<Integer, String>();
	
	private HashMap<String, ExportServices> exportPlugins = new HashMap<String, ExportServices>();
	
	public AlienFormatServices(FileServices fileServices) {
		// TODO Auto-generated constructor stub
		this.fileServices=fileServices;
		
		try {

			registerAvailableExportPlugins();

		} catch (MalformedURLException e) {

			System.out.println("Failed to load export plugins...Export functionality will not work");

		}
		
		
	}

	private void registerAvailableExportPlugins() throws MalformedURLException {
       
		File pluginDirectory= new File(fileServices.getPluginFolder());
		
		URL[] url= {pluginDirectory.toURI().toURL()};
		
		URLClassLoader urlClassLoader =new URLClassLoader(url);
		
		File[] listOfFiles = pluginDirectory.listFiles();
	
		for (int i = 0; i < listOfFiles.length; i++) {
			
		if(listOfFiles[i].isFile()&& listOfFiles[i].getName().endsWith(".class")){
			
			System.out.println("Loading Plugin..."+listOfFiles[i].getName());
			
			try{
			
			registerExportPlugins(listOfFiles[i].getName().replaceAll(".class", ""), urlClassLoader);
			
		}catch(Exception e){
			System.out.println("########## WARNING ##########");
			
			System.out.println("Failed to initialize plugin -" +listOfFiles[i].getName()+", Functionality will not be available");
			
			System.out.println("#############################");
		}
		}
		

			}
		
		}
		
		
	private void registerExportPlugins(String pluginFileName,
			URLClassLoader urlClassLoader) throws InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException, ClassNotFoundException, AlienExceptions {
		
		try {
            
			ExportServices exportServices = (ExportServices) urlClassLoader
					.loadClass(pluginFileName).getConstructor().newInstance();

			exportMenu.put(pluginCounter, exportServices.getFormatName());

			exportPlugins.put(exportServices.getFormatName(), exportServices);

			pluginCounter++;

		} catch (Exception e) {

			throw new AlienExceptions(
					"Encountered an exception while trying to load plugin class "
							+ pluginFileName, e, AlienExceptions.WARNING);

		}

	}
	

	@Override
	public String getPluginDirectory() {
		
		return fileServices.getPluginFolder();
	
	}

	@Override
	public void printAvailableExportMenu() throws AlienExceptions {
      
		if(exportMenu.size()>0){
			
			System.out.println("These are the supported export options with the system");   
			Iterator iterator =exportMenu.entrySet().iterator();
			
			while (iterator.hasNext()) {
				Map.Entry mapEntry = (Map.Entry) iterator.next();
				System.out.println(mapEntry.getKey() + ". " + mapEntry.getValue());
			}
			
			
		}
             else {
			
			throw new AlienExceptions("There are no export options, So you wont be able to export your data. This can be because of failures during plugin load", null, AlienExceptions.WARNING);
			
			
		}
		
	}

	@Override
	public void handleExportOption(Aliens aliens) throws AlienExceptions {
		
		BufferedReader bf= new BufferedReader(new InputStreamReader(System.in));

		String input = null;

		Integer choice;
		
		
		try{
			
			input =bf.readLine();
			
			while(!AlienUtils.isInteger(input) && ! exportMenu.containsKey(Integer.parseInt(input))){
				
				System.out.println("Invalid option, Please select an export method");
				
				printAvailableExportMenu();
				
				input = bf.readLine();
				
			}
			
			choice =new Integer(input);
			
			System.out.println("copy your data -->"+handleExport(exportMenu.get(choice), aliens));
			
		}catch(Exception e){
			
			throw new AlienExceptions("Invalid Input.", e, AlienExceptions.WARNING);
		}
		
	}

	private String handleExport(String format, Aliens alien) throws AlienExceptions {
		
		String fileName=fileServices.getExportFileName(alien.getName()+"_"+alien.getHomePlanet() +"_" + new Date().getTime()+"."+exportPlugins.get(format).getFormatName().toLowerCase());
			
		try {
			exportPlugins.get(format).exportData(alien.getName(),alien.getBloodColor(),alien.getNoOfAnteannas(),alien.getNoOfLegs(),alien.getHomePlanet(),fileName);
		
		} catch (Exception e) {

			throw new AlienExceptions("Failed to export data into the format "+format, e, AlienExceptions.WARNING);
			
		}
		
		
		return fileName;
	}
  
}
