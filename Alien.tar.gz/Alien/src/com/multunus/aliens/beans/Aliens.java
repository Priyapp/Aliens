package com.multunus.aliens.beans;

public class Aliens {

	private String name;
	
	private String bloodColor;
	
	private int noOfAntennas;
	
	private int noOfLegs;
	
	private String homePlanet;
	
	public String getName(){
		return name;
	}
	
	public String getBloodColor(){
		return bloodColor;
	}
	
	public int getNoOfLegs(){
		return noOfLegs;
	}
	
	public int getNoOfAnteannas(){
		return noOfAntennas;
	}
	
	public String getHomePlanet(){
		return homePlanet;
	}
	
	public void setName(String name){
		this.name=name;
	}

	public void setBloodColor(String bloodColor){
		this.bloodColor=bloodColor;
	}
	
	public void setNoOfLegs(int noOfLegs){
		this.noOfLegs=noOfLegs;
	}
	
	public void setNoOfAnteannas(int noOfAntennas){
		this.noOfAntennas=noOfAntennas;
	}
	
	public void setHomePlanet(String homePlanet){
		this.homePlanet=homePlanet;
	}
	
}
