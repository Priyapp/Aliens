

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import com.multunus.aliens.services.ExportServices;

public class CsvExportService implements ExportServices{
	
	private final String formatName="CSV"; 
	
	@Override
	public String getFormatName() {
		// TODO Auto-generated method stub
		return formatName;
	}

	@Override
	public boolean exportData(String alienName, String bloodColor,int noOfAntennas, int noOfLegs, String homePlanet, String fileName)throws Exception {
		
		BufferedWriter bf=null;
		FileWriter file=null;
		try{
			file =new FileWriter(fileName);
			bf= new BufferedWriter(file);
			bf.write("Name, Blood color,No Of antennas, No of legs,Home planet"+System.getProperty("line.separator"));
			bf.write(alienName +","+bloodColor +","+noOfAntennas+","+noOfLegs +","+homePlanet);
			bf.flush();

		}catch(IOException e){
			
			System.out.println("Error:"+e.getMessage());
			
			e.printStackTrace();
			
			return false;
		} finally {
	    	  
	    	  if(bf!=null) {
	    		  bf.close();
	    	  }
	    	  
	    	  if(file!=null) {
	    		  file.close();
	    	  }
	    	  
	      }
	return true;
	}

	
	
}
